mark1 = [0] * (6)
mark2 = [0] * (6)
mark3 = [0] * (6)
mark4 = [0] * (6)
mark5 = [0] * (6)

# arrays are initialised
print(" marks of roll no 1 ")
for indexsub in range(1, 5 + 1, 1):
    
    # each students mark in 5 subjects
    # 1st student
    print(" enter mark for subject [" + str(indexsub) + "]")
    mark = float(input())
    mark1[indexsub] = mark
total1 = mark1[1] + mark1[2] + mark1[3] + mark1[4] + mark1[5]
print(" ROLL NO : 1 ")
print(" TOTAL MARK OF ROLL NO 1 = " + str(total1))
avg1 = total1 / 5
print(" AVERAGE MARK OF ROLL NO 1 = " + str(avg1))

# total and average is found
print(" marks of roll no 2 ")
for indexsub in range(1, 5 + 1, 1):
    
    # marks of second number
    print(" enter mark for subject [" + str(indexsub) + "]")
    mark = float(input())
    mark2[indexsub] = mark
total2 = mark2[1] + mark2[2] + mark2[3] + mark2[4] + mark2[5]
print(" ROLL NO : 2 ")
print(" TOTAL MARK OF ROLL NO 2 = " + str(total2))
avg2 = total2 / 5
print(" AVERAGE MARK OF ROLL NO 2 = " + str(avg2))
print(" marks of roll no 3 ")
for indexsub in range(1, 5 + 1, 1):
    
    # marks of 3rd student
    print(" enter mark for subject [" + str(indexsub) + "]")
    mark = float(input())
    mark3[indexsub] = mark
total3 = mark3[1] + mark3[2] + mark3[3] + mark3[4] + mark3[5]
print(" ROLL NO : 3 ")
print(" TOTAL MARK OF ROLL NO 3 = " + str(total3))
avg3 = total3 / 5
print(" AVERAGE MARK OF ROLL NO 3 = " + str(avg3))
print(" marks of roll no 4 ")
for indexsub in range(1, 5 + 1, 1):
    
    # marks of 4th student
    print(" enter maek for subject [" + str(indexsub) + "]")
    mark = float(input())
    mark4[indexsub] = mark
total4 = mark4[1] + mark4[2] + mark4[3] + mark4[4] + mark4[5]
print(" ROLL NO : 4  ")
print(" TOTAL MARK OF ROLL NO 4 = " + str(total4))
avg4 = total4 / 5
print(" AVERAGE MARK OF ROLL NO 4 = " + str(avg4))

# avg and total is found
print(" marks of roll no 5")
for indexsub in range(1, 5 + 1, 1):
    
    # marks of 5th student
    print(" enter maek for subject [" + str(indexsub) + "]")
    mark = float(input())
    mark5[indexsub] = mark
total5 = mark5[1] + mark5[2] + mark5[3] + mark5[4] + mark5[5]
print(" ROLL NO : 5 ")
print(" TOTAL MARK OF ROLL NO 2 = " + str(total2))
avg5 = total5 / 5
print(" AVERAGE MARK OF ROLL NO 5 = " + str(avg5))

# avg and total is found
