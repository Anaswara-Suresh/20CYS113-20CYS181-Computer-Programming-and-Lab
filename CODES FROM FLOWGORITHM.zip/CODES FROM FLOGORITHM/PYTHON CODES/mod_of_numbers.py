# finding the mod
print(" ENTER THE VALUE OF DIVIDENT ")

# value of dividend given
a = float(input())
print(" ENTER THE VALUE OF DIVISOR ")

# value of divisor given
b = float(input())
q = a / b

# quotient is found
r = a - q * b

# mod or remainder is found
print(" MOD :  ")
print(r)
