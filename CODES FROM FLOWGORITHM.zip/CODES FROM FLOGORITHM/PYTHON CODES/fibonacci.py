# assign variables
i = 0
n = 1
sum = 0

# input values for variables
while n <= 1000:
    sum = i + n
    
    # finding the series or values
    print(sum)
    
    # output the series
    i = n
    n = sum
    
    # loop
