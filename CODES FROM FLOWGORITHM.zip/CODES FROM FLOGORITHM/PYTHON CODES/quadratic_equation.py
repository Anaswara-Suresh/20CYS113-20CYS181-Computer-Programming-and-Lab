# finding the solutions of a quadratic equation
print(" ENTER THE COEFFICIENT OF X^2 ")

# value of a is given
a = int(input())
print(" ENTER THE COEFFICIENT OF X ")

# value of b is given
b = int(input())
print(" ENTER THE VALUE OF CONSTANT  ")

# value of c is given
c = int(input())
value1 = (-b + sqrt(b ** 2 - 4 * a * c)) / 2 * a

# first solution of eqn is calculated
print(" SOLUTIONS : ")
print(value1)
value2 = (-b - sqrt(b ** 2 - 4 * a * c)) / 2 * a

# second solution of eqn is calculated
print(value2)
