# to find largest number in array
# declare the variables
# Get array size
print("Enter array size")
size = int(input())

# Declare array
array = [0] * (size)

i = 0
while i < size:
    print("Enter element number " + str(i + 1))
    array[i] = int(input())
    
    # finding the largest
    if i > 0:
        if array[i] > largest:
            largest = array[i]
    else:
        largest = array[i]
    i = i + 1
print("Largest number in given array is " + str(largest))
