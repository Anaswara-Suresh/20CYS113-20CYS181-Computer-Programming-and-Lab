# variables declared
i = 1
n = 1
sum = 0

# values initialised
for i in range(1, 10 + 1, 1):
    
    # first loop
    for n in range(1, 10 + 1, 1):
        
        # second loop
        sum = i + n
        print(str(i) + "+" + str(n) + "=" + str(sum))
        
        # output the sum
