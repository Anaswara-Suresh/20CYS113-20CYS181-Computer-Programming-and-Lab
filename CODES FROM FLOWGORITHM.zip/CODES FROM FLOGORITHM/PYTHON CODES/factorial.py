# start program
# declare variables
print("enter the number which you need factorial ")
counter = int(input())

# input the counter value
factorial = 1
if counter > 0:
    
    # counter is greater than 0
    while counter > 0:
        
        # calculating the factorial
        factorial = factorial * counter
        counter = counter - 1
    
    # end result is displayed
    print("Factorial = " + str(factorial))
else:
    
    # counter less than 0
    print(" factorial not defined ")
