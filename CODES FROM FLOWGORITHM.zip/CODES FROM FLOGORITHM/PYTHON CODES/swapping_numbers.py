# swapping the numbers
print(" ENTER THE VALUE OF a")

# Value of a is given
a = float(input())
print(" ENTER THE VALUE OF b ")

# value of b is given
b = float(input())
print(" AFTER SWAPPING  ")

# the variable is swapped
print(" value of a ")

# after swapping value of a
print(a / a * b)
print(" value of b ")

# after swapping value of b
print(b / b * a)
