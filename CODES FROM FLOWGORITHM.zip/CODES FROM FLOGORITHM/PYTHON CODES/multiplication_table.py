# variables declared
i = 1
n = 1
prod = 1

# values initialised
for i in range(1, 10 + 1, 1):
    
    # first loop
    for n in range(1, 10 + 1, 1):
        
        # second loop
        prod = i * n
        print(str(i) + "*" + str(n) + "=" + str(prod))
        
        # output the product
