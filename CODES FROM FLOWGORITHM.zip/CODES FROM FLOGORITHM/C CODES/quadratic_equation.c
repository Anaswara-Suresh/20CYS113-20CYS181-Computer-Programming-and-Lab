#include <stdio.h>
#include <math.h>

int main() {
    printf("ENTER THE COEFFICIENT OF X^2\n");
    int a;
    scanf("%d", &a);
    printf("ENTER THE COEFFICIENT OF X\n");
    int b;
    scanf("%d", &b);
    printf("ENTER THE VALUE OF CONSTANT\n");
    int c;
    scanf("%d", &c);
    double discriminant = b * b - 4 * a * c;
    double value1 = (-b + sqrt(discriminant)) / (2 * a);
    double value2 = (-b - sqrt(discriminant)) / (2 * a);
    printf("SOLUTIONS:\n");
    printf("%f\n", value1);
    printf("%f\n", value2);
    return 0;
}
