#include <stdio.h>

int main() {
    // declare variables
    int counter, factorial;
    printf("enter the number which you need factorial: ");
    scanf("%d", &counter);

    // input the counter value
    factorial = 1;
    if (counter > 0) {
        // counter is greater than 0
        while (counter > 0) {
            // calculating the factorial
            factorial = factorial * counter;
            counter = counter - 1;
        }
        // end result is displayed
        printf("Factorial = %d\n", factorial);
    }
    else {
        // counter less than 0
        printf("factorial not defined\n");
    }
    return 0;
}


