#include <stdio.h>

int main() {
    // Declare and initialize variables
    int i = 0;
    int n = 1;
    int sum = 0;
    
    // Loop until n exceeds 1000
    while (n <= 1000) {
        sum = i + n;
        // Output the sum
        printf("%d\n", sum);
        
        // Update variables for next iteration
        i = n;
        n = sum;
    }
    
    return 0;
}


