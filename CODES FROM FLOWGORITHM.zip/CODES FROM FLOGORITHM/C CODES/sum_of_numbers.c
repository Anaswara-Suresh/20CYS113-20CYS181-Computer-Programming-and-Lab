#include <stdio.h>

int main() {
    int i, n, sum;

    // loop for i
    for (i = 1; i <= 10; i++) {

        // loop for n
        for (n = 1; n <= 10; n++) {
            sum = i + n;
            printf("%d+%d=%d\n", i, n, sum);
        }
    }

    return 0;
}
