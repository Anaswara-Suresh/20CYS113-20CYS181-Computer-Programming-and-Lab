#include <stdio.h>

int main() {
    int size, i, largest;
    printf("Enter array size: ");
    scanf("%d", &size);
    int array[size];

    i = 0;
    while (i < size) {
        printf("Enter element number %d: ", i + 1);
        scanf("%d", &array[i]);
        if (i > 0) {
            if (array[i] > largest) {
                largest = array[i];
            }
        } else {
            largest = array[i];
        }
        i = i + 1;
    }
    printf("Largest number in given array is %d\n", largest);
    return 0;
}


