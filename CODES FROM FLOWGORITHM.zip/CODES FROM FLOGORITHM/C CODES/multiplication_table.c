#include <stdio.h>

int main() {
    int i, n, prod;

    // loop for i
    for (i = 1; i <= 10; i++) {

        // loop for n
        for (n = 1; n <= 10; n++) {
            prod = i * n;
            printf("%d*%d=%d\n", i, n, prod);
        }
    }

    return 0;
}
