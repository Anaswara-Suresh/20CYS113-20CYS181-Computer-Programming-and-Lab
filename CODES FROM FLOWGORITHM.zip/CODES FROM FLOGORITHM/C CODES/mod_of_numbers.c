#include <stdio.h>

int main() {
    float a, b, q, r;

    printf("ENTER THE VALUE OF DIVIDEND: ");
    scanf("%f", &a);

    printf("ENTER THE VALUE OF DIVISOR: ");
    scanf("%f", &b);

    q = a / b;
    r = a - q * b;

    printf("MOD: %.2f", r);

    return 0;
}
